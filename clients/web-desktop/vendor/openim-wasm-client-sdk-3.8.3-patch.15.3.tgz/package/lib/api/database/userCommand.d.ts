export declare function processUserCommandGetAll(): Promise<string>;
export declare function processUserCommandAdd(commandStr: string): Promise<string>;
export declare function processUserCommandUpdate(commandStr: string): Promise<string>;
export declare function processUserCommandDelete(commandStr: string): Promise<string>;
