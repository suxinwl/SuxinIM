export declare function getLoginUser(userID: string): Promise<string>;
export declare function insertLoginUser(userStr: string): Promise<string>;
export declare function updateLoginUser(userStr: string): Promise<string>;
export declare function updateLoginUserByMap(userID: string, args: Record<string, unknown> | string): Promise<string>;
