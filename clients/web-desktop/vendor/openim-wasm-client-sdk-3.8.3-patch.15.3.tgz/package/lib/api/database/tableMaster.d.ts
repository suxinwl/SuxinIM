export declare function getExistedTables(): Promise<string>;
export declare function getExistTables(): Promise<string>;
