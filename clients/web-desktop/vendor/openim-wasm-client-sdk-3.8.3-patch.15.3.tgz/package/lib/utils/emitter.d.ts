import { SdkEventEnvelope } from '../types/entity';
import { SdkEvent } from '../constant';
import { SdkEventData } from '../types/eventData';
declare type Cbfn<E extends SdkEvent> = (data: SdkEventEnvelope<SdkEventData<E>>) => void;
declare class Emitter {
    private events;
    constructor();
    emit<E extends SdkEvent>(event: E, data: SdkEventEnvelope<SdkEventData<E>>): this;
    on<E extends SdkEvent>(event: E, fn: Cbfn<E>): this;
    off<E extends SdkEvent>(event: E, fn: Cbfn<E>): this | undefined;
}
export default Emitter;
