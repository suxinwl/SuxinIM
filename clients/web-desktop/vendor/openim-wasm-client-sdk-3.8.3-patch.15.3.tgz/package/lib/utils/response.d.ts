export declare function formatResponse(data: unknown, errCode?: number, errMsg?: unknown): any;
export declare function formatError(error: unknown): string;
