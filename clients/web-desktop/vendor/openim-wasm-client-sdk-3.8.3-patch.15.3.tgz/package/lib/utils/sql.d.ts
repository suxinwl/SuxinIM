import { Database, QueryExecResult } from '@jlongster/sql.js';
export declare type SQLBinding = string | number | null | Uint8Array;
export declare function execPreparedQuery(db: Database, sql: string, bindings?: SQLBinding[]): QueryExecResult[];
