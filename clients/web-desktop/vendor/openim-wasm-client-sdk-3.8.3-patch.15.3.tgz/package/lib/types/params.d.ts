import { MessageEntity, OfflinePush, Picture, AtUserInfo, MessageItem, SelfUserInfo, GroupItem, SignalingInvitation } from './entity';
import { AllowType, GroupJoinSource, GroupVerificationType, MessageType, MessageReceiveOption, GroupMemberRole, GroupMemberFilter, GroupMessageReaderFilter, LogLevel, GroupMentionType, MessageViewType } from './enum';
export declare type WasmPathConfig = {
    coreWasmPath?: string;
    sqlWasmPath?: string;
    debug?: boolean;
};
export declare type LoginParams = {
    userID: string;
    token: string;
    platformID: number;
    apiAddr: string;
    wsAddr: string;
    logLevel?: LogLevel;
    isLogStandardOutput?: boolean;
    isExternalExtensions?: boolean;
    tryParse?: boolean;
};
export declare type ConversationSessionParams = {
    sourceID: string;
    sessionType: number;
};
export declare type GetAdvancedHistoryMessageListParams = {
    count: number;
    viewType: MessageViewType;
    startClientMsgID: string;
    conversationID: string;
};
export declare type GetGroupMemberListParams = {
    groupID: string;
    filter: GroupMemberFilter;
    offset: number;
    count: number;
};
export declare type SendMessageParams = {
    recvID: string;
    groupID: string;
    offlinePushInfo?: OfflinePush;
    message: MessageItem;
    isOnlineOnly?: boolean;
};
export declare type SetMessageLocalExParams = {
    conversationID: string;
    clientMsgID: string;
    localEx: string;
};
export declare type CreateImageMessageByURLParams = {
    sourcePicture: Picture;
    bigPicture: Picture;
    snapshotPicture: Picture;
    sourcePath: string;
};
export declare type CreateVideoMessageByURLParams = {
    videoPath: string;
    duration: number;
    videoType: string;
    snapshotPath: string;
    videoUUID: string;
    videoUrl: string;
    videoSize: number;
    snapshotUUID: string;
    snapshotSize: number;
    snapshotUrl: string;
    snapshotWidth: number;
    snapshotHeight: number;
    snapShotType?: string;
};
export declare type CreateCustomMessageParams = {
    data: string;
    extension: string;
    description: string;
};
export declare type CreateQuoteMessageParams = {
    text: string;
    message: string;
};
export declare type CreateAdvancedQuoteMessageParams = {
    text: string;
    message: MessageItem;
    messageEntityList?: MessageEntity[];
};
export declare type CreateAdvancedTextMessageParams = {
    text: string;
    messageEntityList?: MessageEntity[];
};
export declare type SetConversationParams = {
    conversationID: string;
    recvMsgOpt?: MessageReceiveOption;
    groupAtType?: GroupMentionType;
    burnDuration?: number;
    msgDestructTime?: number;
    isPinned?: boolean;
    isPrivateChat?: boolean;
    isMsgDestruct?: boolean;
    ex?: string;
};
export declare type ConversationListPaginationParams = {
    offset: number;
    count: number;
};
export declare type SetConversationDraftParams = {
    conversationID: string;
    draftText: string;
};
export declare type JoinGroupParams = {
    groupID: string;
    reqMsg: string;
    joinSource: GroupJoinSource;
    ex?: string;
};
export declare type SearchGroupsParams = {
    keywordList: string[];
    isSearchGroupID: boolean;
    isSearchGroupName: boolean;
};
export declare type ChangeGroupMuteParams = {
    groupID: string;
    isMute: boolean;
};
export declare type ChangeGroupMemberMuteParams = {
    groupID: string;
    userID: string;
    mutedSeconds: number;
};
export declare type TransferGroupOwnerParams = {
    groupID: string;
    newOwnerUserID: string;
};
export declare type HandleGroupApplicationParams = {
    groupID: string;
    fromUserID: string;
    handleMsg: string;
};
export declare type CreateTextAtMessageParams = {
    text: string;
    atUserIDList: string[];
    atUsersInfo?: AtUserInfo[];
    message?: MessageItem;
};
export declare type CreateSoundMessageByURLParams = {
    uuid: string;
    soundPath: string;
    sourceUrl: string;
    dataSize: number;
    duration: number;
    soundType?: string;
};
export declare type CreateFileMessageByURLParams = {
    filePath: string;
    fileName: string;
    uuid: string;
    sourceUrl: string;
    fileSize: number;
    fileType?: string;
};
export declare type CreateMergerMessageParams = {
    messageList: MessageItem[];
    title: string;
    summaryList: string[];
};
export declare type CreateFaceMessageParams = {
    index: number;
    data: string;
};
export declare type CreateLocationMessageParams = {
    description: string;
    longitude: number;
    latitude: number;
};
export declare type InsertSingleMessageToLocalStorageParams = {
    message: MessageItem;
    recvID: string;
    sendID: string;
};
export declare type InsertGroupMessageToLocalStorageParams = {
    message: MessageItem;
    groupID: string;
    sendID: string;
};
export declare type ConversationMessageParams = {
    conversationID: string;
    clientMsgID: string;
};
export declare type MessageReadReceiptParams = {
    conversationID: string;
    clientMsgIDList: string[];
};
export declare type ChangeInputStatesParams = {
    conversationID: string;
    focus: boolean;
};
export declare type GetInputStatesParams = {
    conversationID: string;
    userID: string;
};
export declare type SearchLocalMessagesParams = {
    conversationID: string;
    keywordList: string[];
    keywordListMatchType?: number;
    senderUserIDList?: string[];
    messageTypeList?: MessageType[];
    searchTimePosition?: number;
    searchTimePeriod?: number;
    pageIndex?: number;
    count?: number;
};
export declare type AddFriendParams = {
    toUserID: string;
    reqMsg: string;
};
export declare type SearchFriendsParams = {
    keywordList: string[];
    isSearchUserID: boolean;
    isSearchNickname: boolean;
    isSearchRemark: boolean;
};
export declare type GetSpecifiedFriendsParams = {
    friendUserIDList: string[];
    filterBlack?: boolean;
};
export declare type UpdateFriendsParams = {
    friendUserIDs: string[];
    isPinned?: boolean;
    remark?: string;
    ex?: string;
};
export declare type HandleFriendApplicationParams = {
    toUserID: string;
    handleMsg: string;
};
export declare type AddBlackParams = {
    toUserID: string;
    ex?: string;
};
export declare type GroupMemberUserListParams = {
    groupID: string;
    userIDList: string[];
};
export declare type GroupMemberOperationParams = GroupMemberUserListParams & {
    reason: string;
};
export declare type GetGroupMemberListByJoinTimeFilterParams = {
    groupID: string;
    filterUserIDList: string[];
    offset: number;
    count: number;
    joinTimeBegin: number;
    joinTimeEnd: number;
};
export declare type SearchGroupMembersParams = {
    groupID: string;
    keywordList: string[];
    isSearchUserID: boolean;
    isSearchMemberNickname: boolean;
    offset: number;
    count: number;
};
export declare type PaginationParams = {
    offset: number;
    count: number;
};
export declare type CreateGroupParams = {
    memberUserIDs: string[];
    groupInfo: Partial<GroupItem>;
    adminUserIDs?: string[];
    ownerUserID?: string;
};
export declare type SetGroupMemberInfoParams = {
    groupID: string;
    userID: string;
    nickname?: string;
    faceURL?: string;
    roleLevel?: GroupMemberRole;
    ex?: string;
};
export declare type FindMessageQuery = {
    conversationID: string;
    clientMsgIDList: string[];
};
export declare type UploadFileParams = {
    name: string;
    contentType: string;
    uuid: string;
    file?: File;
    filepath?: string;
    cause?: string;
};
export declare type SetSelfInfoParams = Partial<Pick<SelfUserInfo, 'nickname' | 'faceURL' | 'ex' | 'globalRecvMsgOpt' | 'addFriendPermission'>>;
export declare type GroupApplicationListParams = {
    groupIDs: string[];
    handleResults: number[];
    offset: number;
    count: number;
};
export declare type GetFriendApplicationListAsRecipientParams = {
    handleResults: number[];
    offset: number;
    count: number;
};
export declare type GetFriendApplicationListAsApplicantParams = {
    offset: number;
    count: number;
};
export declare type ApplicationUnhandledCountParams = {
    time: number;
};
/** @deprecated Use `LoginParams` instead. */
export declare type InitAndLoginConfig = LoginParams;
/** @deprecated Use `ConversationSessionParams` instead. */
export declare type GetOneConversationParams = ConversationSessionParams;
/** @deprecated Use `GetAdvancedHistoryMessageListParams` instead. */
export declare type GetAdvancedHistoryMsgParams = GetAdvancedHistoryMessageListParams;
/** @deprecated Use the Core-aligned surrounding-message parameters instead. */
export declare type FetchSurroundingParams = {
    startMessage: MessageItem;
    viewType: MessageViewType;
    before: number;
    after: number;
};
/** @deprecated Use the Core-aligned history-message parameters instead. */
export declare type GetHistoryMsgParams = {
    userID: string;
    groupID: string;
    count: number;
    startClientMsgID: string;
    conversationID?: string;
};
/** @deprecated Use `MessageReadReceiptParams` instead. */
export declare type SendGroupReadReceiptParams = MessageReadReceiptParams;
/** @deprecated Use the Core-aligned group reader parameters instead. */
export declare type GetGroupMessageReaderParams = {
    conversationID: string;
    clientMsgID: string;
    filter: GroupMessageReaderFilter;
    offset: number;
    count: number;
};
/** @deprecated Use `GetGroupMemberListParams` instead. */
export declare type GetGroupMemberParams = GetGroupMemberListParams;
/** @deprecated Use `SendMessageParams` instead. */
export declare type SendMsgParams = SendMessageParams;
/** @deprecated Use `CreateImageMessageByURLParams` instead. */
export declare type ImageMsgParamsByURL = CreateImageMessageByURLParams;
/** @deprecated Use `CreateVideoMessageByURLParams` instead. */
export declare type VideoMsgParamsByURL = CreateVideoMessageByURLParams;
/** @deprecated Use the Core-aligned video message parameters instead. */
export declare type VideoMsgParamsByFullPath = {
    videoFullPath: string;
    videoType: string;
    duration: number;
    snapshotFullPath: string;
};
/** @deprecated Use `CreateCustomMessageParams` instead. */
export declare type CustomMsgParams = CreateCustomMessageParams;
/** @deprecated Use `CreateQuoteMessageParams` instead. */
export declare type QuoteMsgParams = CreateQuoteMessageParams;
/** @deprecated Use `CreateAdvancedQuoteMessageParams` instead. */
export declare type AdvancedQuoteMsgParams = CreateAdvancedQuoteMessageParams;
/** @deprecated Use `CreateAdvancedTextMessageParams` instead. */
export declare type AdvancedMsgParams = CreateAdvancedTextMessageParams;
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetConversationPrivateStateParams = {
    conversationID: string;
    isPrivate: boolean;
};
/** @deprecated Use `ConversationListPaginationParams` instead. */
export declare type SplitConversationParams = ConversationListPaginationParams;
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetConversationPinParams = {
    conversationID: string;
    isPinned: boolean;
};
/** @deprecated Use `SearchGroupsParams` instead. */
export declare type SearchGroupParams = SearchGroupsParams;
/** @deprecated Use `TransferGroupOwnerParams` instead. */
export declare type TransferGroupParams = TransferGroupOwnerParams;
/** @deprecated Use `HandleGroupApplicationParams` instead. */
export declare type AccessGroupApplicationParams = HandleGroupApplicationParams;
/** @deprecated Use `SetGroupMemberInfoParams` instead. */
export declare type SetGroupRoleParams = {
    groupID: string;
    userID: string;
    roleLevel: GroupMemberRole;
};
/** @deprecated Use the Core-aligned group verification parameters instead. */
export declare type SetGroupVerificationParams = {
    verification: GroupVerificationType;
    groupID: string;
};
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetBurnDurationParams = {
    conversationID: string;
    burnDuration: number;
};
/** @deprecated Use `CreateTextAtMessageParams` instead. */
export declare type AtMsgParams = CreateTextAtMessageParams;
/** @deprecated Use `CreateSoundMessageByURLParams` instead. */
export declare type SoundMsgParamsByURL = CreateSoundMessageByURLParams;
/** @deprecated Use `CreateFileMessageByURLParams` instead. */
export declare type FileMsgParamsByURL = CreateFileMessageByURLParams;
/** @deprecated Use the Core-aligned file message parameters instead. */
export declare type FileMsgParamsByFullPath = {
    fileFullPath: string;
    fileName: string;
};
/** @deprecated Use the Core-aligned sound message parameters instead. */
export declare type SoundMsgParamsByFullPath = {
    soundPath: string;
    duration: number;
};
/** @deprecated Use `CreateMergerMessageParams` instead. */
export declare type MergerMsgParams = CreateMergerMessageParams;
/** @deprecated Use `CreateFaceMessageParams` instead. */
export declare type FaceMessageParams = CreateFaceMessageParams;
/** @deprecated Use `CreateLocationMessageParams` instead. */
export declare type LocationMsgParams = CreateLocationMessageParams;
/** @deprecated Use `InsertSingleMessageToLocalStorageParams` instead. */
export declare type InsertSingleMsgParams = InsertSingleMessageToLocalStorageParams;
/** @deprecated Use `InsertGroupMessageToLocalStorageParams` instead. */
export declare type InsertGroupMsgParams = InsertGroupMessageToLocalStorageParams;
/** @deprecated Use `ConversationMessageParams` instead. */
export declare type AccessMessageParams = ConversationMessageParams;
/** @deprecated Use `ChangeInputStatesParams` instead. */
export declare type TypingUpdateParams = {
    recvID: string;
    msgTip: string;
};
/** @deprecated Use `GetInputStatesParams` instead. */
export declare type GetInputstatesParams = GetInputStatesParams;
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetConversationExParams = {
    conversationID: string;
    ex: string;
};
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetConversationRecvOptParams = {
    conversationID: string;
    opt: MessageReceiveOption;
};
/** @deprecated Use `SearchLocalMessagesParams` instead. */
export declare type SearchLocalParams = SearchLocalMessagesParams;
/** @deprecated Use `SearchFriendsParams` instead. */
export declare type SearchFriendParams = SearchFriendsParams;
/** @deprecated Use `UpdateFriendsParams` instead. */
export declare type RemarkFriendParams = {
    toUserID: string;
    remark: string;
};
/** @deprecated Use `UpdateFriendsParams` instead. */
export declare type PinFriendParams = {
    toUserIDs: string[];
    isPinned: boolean;
};
/** @deprecated Use `UpdateFriendsParams` instead. */
export declare type SetFriendExParams = {
    toUserIDs: string[];
    ex: string;
};
/** @deprecated Use `HandleFriendApplicationParams` instead. */
export declare type AccessFriendApplicationParams = HandleFriendApplicationParams;
/** @deprecated Use `GroupMemberOperationParams` instead. */
export declare type AccessToGroupParams = GroupMemberOperationParams;
/** @deprecated Use `GetGroupMemberListByJoinTimeFilterParams` instead. */
export declare type GetGroupMemberByTimeParams = GetGroupMemberListByJoinTimeFilterParams;
/** @deprecated Use `SearchGroupMembersParams` instead. */
export declare type SearchGroupMemberParams = SearchGroupMembersParams;
/** @deprecated Use the Core-aligned group permission parameters instead. */
export declare type SetMemberPermissionParams = {
    rule: AllowType;
    groupID: string;
};
/** @deprecated Use `PaginationParams` instead. */
export declare type OffsetParams = PaginationParams;
/** @deprecated Use `SetGroupMemberInfoParams` instead. */
export declare type SetGroupMemberNickParams = {
    groupID: string;
    userID: string;
    groupMemberNickname: string;
};
/** @deprecated Use `SetGroupMemberInfoParams` instead. */
export declare type UpdateMemberInfoParams = SetGroupMemberInfoParams;
/** @deprecated Use `FindMessageQuery` instead. */
export declare type FindMessageParams = FindMessageQuery;
/** @deprecated Use `SetSelfInfoParams` instead. */
export declare type PartialUserItem = Partial<SelfUserInfo>;
/** @deprecated Use the Core-aligned signaling invitation parameters instead. */
export declare type SignalingInviteParams = {
    invitation: SignalingInvitation;
    offlinePushInfo?: OfflinePush;
};
/** @deprecated Use the Core-aligned signaling action parameters instead. */
export declare type RtcActionParams = {
    opUserID: string;
    invitation: SignalingInvitation;
};
/** @deprecated Use the Core-aligned custom signaling parameters instead. */
export declare type CustomSignalParams = {
    roomID: string;
    customInfo: string;
};
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetConversationMsgDestructParams = {
    conversationID: string;
    isMsgDestruct: boolean;
};
/** @deprecated Use `SetConversationParams` instead. */
export declare type SetConversationMsgDestructTimeParams = {
    conversationID: string;
    msgDestructTime: number;
};
/** @deprecated Use `GroupApplicationListParams` instead. */
export declare type GetGroupApplicationListParams = {
    groupID: string[];
    handleResults: number[];
    offset: number;
    count: number;
};
/** @deprecated Use `GetFriendApplicationListAsApplicantParams` instead. */
export declare type GetFriendApplicationListAsApplicationParams = GetFriendApplicationListAsApplicantParams;
/** @deprecated Use `ApplicationUnhandledCountParams` instead. */
export declare type GetFriendApplicationUnhandledCountParams = ApplicationUnhandledCountParams;
/** @deprecated Use `ApplicationUnhandledCountParams` instead. */
export declare type GetSelfUnhandledApplyCountParams = ApplicationUnhandledCountParams;
