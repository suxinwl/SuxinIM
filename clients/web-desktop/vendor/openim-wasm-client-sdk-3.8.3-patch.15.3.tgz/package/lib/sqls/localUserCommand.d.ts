import { Database, QueryExecResult } from '@jlongster/sql.js';
export declare type LocalUserCommand = {
    [key: string]: unknown;
};
export declare function localUserCommands(db: Database): QueryExecResult[];
export declare function processUserCommandGetAll(db: Database): QueryExecResult[];
export declare function processUserCommandAdd(db: Database, command: LocalUserCommand): QueryExecResult[];
export declare function processUserCommandUpdate(db: Database, command: LocalUserCommand): QueryExecResult[];
export declare function processUserCommandDelete(db: Database, command: LocalUserCommand): QueryExecResult[];
