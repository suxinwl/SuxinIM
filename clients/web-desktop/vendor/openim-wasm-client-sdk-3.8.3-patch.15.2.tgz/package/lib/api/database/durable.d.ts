import type { Database } from '@jlongster/sql.js';
declare type Tombstone = {
    conversationIDs: string[] | null;
    beforeMS: number;
    messageIDs?: string[];
};
export declare type MessageSuppression = {
    conversationID: string;
    clientMsgID: string;
    sendTime: number;
    mode: 'delete' | 'archive';
};
export declare function durableEnabled(): boolean;
export declare function detachMemoryDatabase(): void;
export declare function restoreMemoryDatabase(): Promise<{
    bytes?: Uint8Array;
    entries: any[];
    tombstones: Tombstone[];
    suppression: MessageSuppression[];
}>;
export declare function splitSQL(sql: string): string[];
export declare function attachMemoryDatabase(db: Database, entries: any[], tombstones: Tombstone[], suppression?: MessageSuppression[]): Database;
export declare function durableMethod(name: string, fn: (...args: any[]) => any): (...args: any[]) => any;
declare type LocalCleanupScope = {
    conversationIDs?: string[];
    beforeMS?: number;
    beforeDate?: string;
};
export declare function localCleanupPreview(input: LocalCleanupScope): Promise<any>;
export declare function localCleanup(input: LocalCleanupScope): Promise<{
    cleaned: boolean;
}>;
export {};
